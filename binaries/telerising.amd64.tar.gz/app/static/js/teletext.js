$(document).ready(function() {

    // Change root location
    $("#go-to-home").prop("href", window.location.href.replace(new RegExp('/teletext$'), ""));

    // Load txt config file

    $.getJSON("/static/json/teletext.json", function(data) {
        $.each(data, function(key, item) {
            $("#txt-selection").append($("<option>", {
                value: item.q,
                id: item.id,
                text: key
            }))
        });
    });

    $(".card").fadeIn(500).prop("hidden", false)
    $(".first-input").focus()

    $("#txt-selection").on("change", function() {
        var selectedChannelId = $("#txt-selection").children("option:selected").val();
        if( selectedChannelId != "txt_none" ) {
            $("#submit-txt-form").prop("disabled", false);
            $("#txt-page-selection").prop("disabled", false);
            $("#txt-subpage-selection").prop("disabled", false);
        };
    });

    $("#submit-txt-form").on("click", function() {
        GoOn()
    });

    function GoOn() {
        var selectedChannelId = $("#txt-selection").children("option:selected").attr("id");
        var selectedChannelQuality = $("#txt-selection").children("option:selected").val();
        var selectedPage = $("#txt-page-selection").val();
        var selectedSubPage = $("#txt-subpage-selection").val();
        if( selectedPage === "100" && selectedSubPage === "1" ) {
            window.open("https://zattoo-abox.zattoo.com/assets/teletext.html?quality=" + selectedChannelQuality + "&cid=" + selectedChannelId);
        } else {
            window.open("https://zapi.zattoo.com/teletext/" + selectedChannelId + "/" + selectedChannelQuality + "/" + selectedPage + "/" + selectedSubPage + ".html");
        };
    };
});