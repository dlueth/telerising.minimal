$(document).ready(function() {

    // Change root location
    $("#go-to-home").prop("href", window.location.href.replace(new RegExp('/login$'), ""));

    $(".verification-error").hide()
    $(".card").fadeIn(500).prop("hidden", false)
    $(".first-input").focus()

    $("#login-password").on("input", function() {
        if( $("#login-password").val().length >= 8 ) {
            $("#submit-login-form").prop("disabled", false)
        } else {
            $("#submit-login-form").prop("disabled", true)
        }
    });

    $("#login-password").on("keypress", function(e) {
        if( $("#login-password").val().length > 0 ) {
            if(e.which == 13) {
                    GoOn()
            }
        }
    });

    $("#submit-login-form").on("click", function() {
        GoOn()
    });

    function GoOn() {

        $("#submit-login-form").prop("disabled", true)
        $("#submit-login-form").text("Checking...")
        if( !$(".verification-error").is(":hidden") ) {
            $(".verification-error").prop("style", "margin-top: 3px; color: red; opacity: 0.5")
        }
        $.ajax({
            type: "POST",
            url: "api/login_check",
            data: {
                pw: $("#login-password").val()
            },
            datatype: "json",
            success: function(info) {
                if( info.success === true ) {
                    window.location.href = "/"
                } else {
                    $("#submit-login-form").text('Login')
                    $("#submit-login-form").prop("disabled", false)
                    $(".verification-error-message").text(info.message)
                    if( $(".verification-error").is(":hidden") ) {
                        $(".verification-error").prop("hidden", false).slideDown(500)
                    } else {
                        $(".verification-error").prop("style", "margin-top: 3px; color: red; opacity: 1")
                    }
                }
            },
            error: function(info) {
                $("#submit-login-form").text("Login")
                $("#submit-login-form").prop("disabled", false)
                $(".verification-error-message").text("Failed to retrieve API status")
                if( $(".verification-error").is(":hidden") ) {
                    $(".verification-error").prop("hidden", false).slideDown(500)
                } else {
                    $(".verification-error").prop("style", "margin-top: 3px; color: red; opacity: 1")
                }
            }
        });
    };
});